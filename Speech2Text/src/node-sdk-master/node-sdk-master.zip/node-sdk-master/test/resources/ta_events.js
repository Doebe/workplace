[{
	"widget_instance_uuid" : "e8d263d9-a0a7-43f4-81cf-2767ad246cb5",
	"widget_show_uuid" : null,
	"dilemma_call_uuid" : null,
	"event_number" : 0,
	"category" : "widget",
	"action" : "started",
	"object" : "basic",
	"value" : {
		"optionHighlighting" : false,
		"favorites" : true,
		"favoritesTab" : false,
		"optionDetails" : true,
		"filters" : true,
		"filterHistogram" : false,
		"objectivesOnly" : true,
		"optimalsList" : true,
		"autoExcludedList" : true,
		"incompleteList" : true,
		"tradeoffAnalyzer" : true,
		"undoRedo" : false,
		"exploreViz" : "both",
		"questionEditor" : "editableNoToggle",
		"bidiTextDir" : "auto",
		"analytics" : "MetadataAndEvents"
	},
	"timestamp" : 1442414658641
}]
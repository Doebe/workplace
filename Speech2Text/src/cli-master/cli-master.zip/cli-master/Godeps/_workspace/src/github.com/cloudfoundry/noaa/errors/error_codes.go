package errors

const ERR_LOST_CONNECTION = int32(1)
const ERR_DIAL = int32(2)

var foo = require('./foo');
console.log('xyz: ' + foo(6));

t.fail('only entry files should get executed right away');

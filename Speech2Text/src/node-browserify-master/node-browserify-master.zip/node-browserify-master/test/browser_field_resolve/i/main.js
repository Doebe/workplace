var x = require('./x.js')
console.log(x)

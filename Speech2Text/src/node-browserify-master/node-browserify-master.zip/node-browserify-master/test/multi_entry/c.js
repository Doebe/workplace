times ++;
t.equal(times, 3);

var a = require('aaa');
var b = require('bbb');

console.log(5);
console.log(a);
console.log(b);

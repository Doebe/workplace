module.exports = {
    a: require("./a"),
    b:  require("./b")
};

module.exports = require('./three.js') - 1;

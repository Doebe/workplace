module.exports = {
    b: true,
    1: require('./dir1/1'),
    robot: require('robot')
};

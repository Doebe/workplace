t.deepEqual(require('events'), {});
t.deepEqual(require('bad id'), {});
t.deepEqual(require('beep'), {});
console.log('main line 1');
var foo = require('./foo.js');

foo();
